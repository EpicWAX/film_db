<!DOCTYPE html>
<html>
	<head>
		<title>Vue des films</title>
	</head>
	<body>
		<p>NEW DESIGN FOR READ INFO FILM<p>



	</body>
</html>